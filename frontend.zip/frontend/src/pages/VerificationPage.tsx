import { useState, useRef } from "react";
import { motion } from "framer-motion";
import styles from "./VerificationPage.module.css";
import Loading from "@components/Loading";
import FNDB from "../assets/FNDbackground.png";

interface VerificationResult {
  summary: {
    total_claims: number;
    true_count: number;
    false_count: number;
    neutral_count: number;
    highest_risk: string;
  };
  language_support: string;
  language_name: string;
  primary_language: string;
  visual_forensics?: {
    suspicion_level: string;
  };
  results: Array<{
    claim_id: string;
    claim: string;
    user_label: string;
    confidence: number;
    short_explain_local: string;
    short_explain_en: string;
    virality_score: number;
    combined_risk_level: string;
    evidence?: Array<{
      source_type: string;
      title: string;
      credibility_score: number;
      url: string;
    }>;
    receipt_pdf_path?: string;
    needs_human_review?: boolean;
  }>;
}

interface MetadataOptions {
  views?: number;
  likes?: number;
  shares?: number;
  comments?: number;
}

type TabType = "text" | "url" | "image" | "video" | "pdf";

const VerificationPage = () => {
  const [activeTab, setActiveTab] = useState<TabType>("text");
  const [textInput, setTextInput] = useState("");
  const [urlInput, setUrlInput] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [metadata, setMetadata] = useState<MetadataOptions>({
    views: 1000,
    likes: 100,
    shares: 50,
    comments: 20,
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [showEvidence, setShowEvidence] = useState(true);
  const [showWorkflow, setShowWorkflow] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleVerifyText = async () => {
    if (!textInput.trim()) {
      alert("Please enter some text to verify");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("http://localhost:8000/api/verify/text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: textInput,
          ...metadata,
        }),
      });

      const data = await response.json();
      // Poll for job status
      await pollJobStatus(data.job_id);
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to verify text");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyUrl = async () => {
    if (!urlInput.trim()) {
      alert("Please enter a URL");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("url", urlInput);

      const response = await fetch("http://localhost:8000/api/verify/url", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      await pollJobStatus(data.job_id);
    } catch (error) {
      console.error("Error:", error);
      alert("Failed to verify URL");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyFile = async (type: "image" | "video" | "pdf") => {
    if (!file) {
      alert("Please upload a file");
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch(`http://localhost:8000/api/verify/${type}`, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      await pollJobStatus(data.job_id);
    } catch (error) {
      console.error("Error:", error);
      alert(`Failed to verify ${type}`);
    } finally {
      setLoading(false);
    }
  };

  const pollJobStatus = async (jobId: string) => {
    const maxAttempts = 60;
    let attempts = 0;

    const poll = async () => {
      try {
        const response = await fetch(
          `http://localhost:8000/api/job/${jobId}/status`
        );
        const data = await response.json();

        if (data.status === "completed") {
          setResult(data.result);
          return true;
        } else if (data.status === "failed") {
          alert("Verification failed: " + data.error);
          return true;
        } else if (attempts >= maxAttempts) {
          alert("Verification timed out");
          return true;
        }

        attempts++;
        await new Promise((resolve) => setTimeout(resolve, 2000));
        return poll();
      } catch (error) {
        console.error("Polling error:", error);
        return true;
      }
    };

    await poll();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0] || null;
    setFile(selectedFile);
  };

  const clearResults = () => {
    setResult(null);
    setTextInput("");
    setUrlInput("");
    setFile(null);
  };

  const getRiskColor = (risk: string) => {
    const colors = {
      low: "#28a745",
      medium: "#ffc107",
      high: "#fd7e14",
      critical: "#dc3545",
    };
    return colors[risk as keyof typeof colors] || "#6c757d";
  };

  const getRiskEmoji = (risk: string) => {
    const emojis = {
      low: "🟢",
      medium: "🟡",
      high: "🟠",
      critical: "🔴",
    };
    return emojis[risk as keyof typeof emojis] || "⚪";
  };

  return (
    <div className={styles.pageWrap}>
      <img src={FNDB} alt="background" className={styles.pageBg} />

      <div className={styles.container}>
        {/* Header */}
        <motion.div
          className={styles.header}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className={styles.mainTitle}>🛡️ VERITAS GUARDIAN</h1>
          <p className={styles.subtitle}>
            Multi-Agent Misinformation Verification System
          </p>
        </motion.div>

        {/* Sidebar Settings */}
        <div className={styles.sidebar}>
          <h3>ℹ️ About</h3>
          <p className={styles.aboutText}>
            <strong>Veritas Guardian</strong> uses 6 AI agents to verify any
            content:
          </p>
          <ul className={styles.agentList}>
            <li>🎬 <strong>Ingestion</strong> - Extract text from any media</li>
            <li>🌍 <strong>Claims</strong> - Detect language & extract facts</li>
            <li>🔍 <strong>Evidence</strong> - Search reliable sources</li>
            <li>✅ <strong>Verification</strong> - AI-powered fact-checking</li>
            <li>📊 <strong>Virality</strong> - Assess spread & risk</li>
            <li>📄 <strong>Synthesis</strong> - Generate reports</li>
          </ul>

          <div className={styles.settingsSection}>
            <h3>⚙️ Settings</h3>
            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked={showWorkflow}
                onChange={(e) => setShowWorkflow(e.target.checked)}
              />
              Show Agent Workflow
            </label>
            <label className={styles.checkboxLabel}>
              <input
                type="checkbox"
                checked={showEvidence}
                onChange={(e) => setShowEvidence(e.target.checked)}
              />
              Show All Evidence
            </label>
          </div>
        </div>

        {/* Main Content */}
        <div className={styles.mainContent}>
          {/* Tabs */}
          <div className={styles.tabs}>
            {(["text", "url", "image", "video", "pdf"] as TabType[]).map(
              (tab) => (
                <button
                  key={tab}
                  className={`${styles.tab} ${
                    activeTab === tab ? styles.activeTab : ""
                  }`}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab === "text" && "📝 Text"}
                  {tab === "url" && "🔗 URL"}
                  {tab === "image" && "🖼️ Image"}
                  {tab === "video" && "🎥 Video"}
                  {tab === "pdf" && "📄 PDF"}
                </button>
              )
            )}
          </div>

          {/* Tab Content */}
          <div className={styles.tabContent}>
            {/* Text Tab */}
            {activeTab === "text" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={styles.inputSection}
              >
                <h2>Verify Text Content</h2>
                <textarea
                  className={styles.textarea}
                  placeholder="Paste any text, WhatsApp message, tweet, or claim here..."
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  rows={6}
                />

                <div className={styles.metadataRow}>
                  <div className={styles.metadataInput}>
                    <label>Views (optional)</label>
                    <input
                      type="number"
                      min="0"
                      value={metadata.views}
                      onChange={(e) =>
                        setMetadata({
                          ...metadata,
                          views: parseInt(e.target.value),
                        })
                      }
                    />
                  </div>
                  <div className={styles.metadataInput}>
                    <label>Likes (optional)</label>
                    <input
                      type="number"
                      min="0"
                      value={metadata.likes}
                      onChange={(e) =>
                        setMetadata({
                          ...metadata,
                          likes: parseInt(e.target.value),
                        })
                      }
                    />
                  </div>
                  <div className={styles.metadataInput}>
                    <label>Shares (optional)</label>
                    <input
                      type="number"
                      min="0"
                      value={metadata.shares}
                      onChange={(e) =>
                        setMetadata({
                          ...metadata,
                          shares: parseInt(e.target.value),
                        })
                      }
                    />
                  </div>
                  <div className={styles.metadataInput}>
                    <label>Comments (optional)</label>
                    <input
                      type="number"
                      min="0"
                      value={metadata.comments}
                      onChange={(e) =>
                        setMetadata({
                          ...metadata,
                          comments: parseInt(e.target.value),
                        })
                      }
                    />
                  </div>
                </div>

                <button
                  className={styles.verifyBtn}
                  onClick={handleVerifyText}
                  disabled={loading}
                >
                  {loading ? <Loading /> : "🔍 Verify Text"}
                </button>
              </motion.div>
            )}

            {/* URL Tab */}
            {activeTab === "url" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={styles.inputSection}
              >
                <h2>Verify URL Content</h2>
                <input
                  type="text"
                  className={styles.input}
                  placeholder="https://example.com/article or YouTube URL"
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                />
                <button
                  className={styles.verifyBtn}
                  onClick={handleVerifyUrl}
                  disabled={loading}
                >
                  {loading ? <Loading /> : "🔍 Verify URL"}
                </button>
              </motion.div>
            )}

            {/* Image Tab */}
            {activeTab === "image" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={styles.inputSection}
              >
                <h2>Verify Image Content</h2>
                <p className={styles.helpText}>
                  Upload screenshots, memes, or any image with text
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className={styles.fileInput}
                />
                {file && (
                  <div className={styles.filePreview}>
                    <img
                      src={URL.createObjectURL(file)}
                      alt="Preview"
                      className={styles.imagePreview}
                    />
                  </div>
                )}
                <button
                  className={styles.verifyBtn}
                  onClick={() => handleVerifyFile("image")}
                  disabled={loading || !file}
                >
                  {loading ? <Loading /> : "🔍 Verify Image"}
                </button>
              </motion.div>
            )}

            {/* Video Tab */}
            {activeTab === "video" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={styles.inputSection}
              >
                <h2>Verify Video Content</h2>
                <p className={styles.helpText}>
                  First 30 seconds will be analyzed
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/*"
                  onChange={handleFileChange}
                  className={styles.fileInput}
                />
                {file && (
                  <div className={styles.filePreview}>
                    <video
                      src={URL.createObjectURL(file)}
                      controls
                      className={styles.videoPreview}
                    />
                  </div>
                )}
                <button
                  className={styles.verifyBtn}
                  onClick={() => handleVerifyFile("video")}
                  disabled={loading || !file}
                >
                  {loading ? <Loading /> : "🔍 Verify Video"}
                </button>
              </motion.div>
            )}

            {/* PDF Tab */}
            {activeTab === "pdf" && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={styles.inputSection}
              >
                <h2>Verify PDF Content</h2>
                <p className={styles.helpText}>
                  Extract and verify text from PDF documents
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf"
                  onChange={handleFileChange}
                  className={styles.fileInput}
                />
                {file && (
                  <div className={styles.fileInfo}>
                    📄 {file.name} ({Math.round(file.size / 1024)} KB)
                  </div>
                )}
                <button
                  className={styles.verifyBtn}
                  onClick={() => handleVerifyFile("pdf")}
                  disabled={loading || !file}
                >
                  {loading ? <Loading /> : "🔍 Verify PDF"}
                </button>
              </motion.div>
            )}
          </div>

          {/* Results Section */}
          {result && (
            <motion.div
              className={styles.results}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h2 className={styles.resultsTitle}>📊 Verification Results</h2>

              {/* Summary Metrics */}
              <div className={styles.summaryMetrics}>
                <div className={styles.metric}>
                  <div className={styles.metricValue}>
                    {result.summary.total_claims}
                  </div>
                  <div className={styles.metricLabel}>Total Claims</div>
                </div>
                <div className={styles.metric}>
                  <div className={styles.metricValue} style={{ color: "#28a745" }}>
                    {result.summary.true_count}
                  </div>
                  <div className={styles.metricLabel}>✅ True</div>
                </div>
                <div className={styles.metric}>
                  <div className={styles.metricValue} style={{ color: "#dc3545" }}>
                    {result.summary.false_count}
                  </div>
                  <div className={styles.metricLabel}>❌ False</div>
                </div>
                <div className={styles.metric}>
                  <div className={styles.metricValue} style={{ color: "#ffc107" }}>
                    {result.summary.neutral_count}
                  </div>
                  <div className={styles.metricLabel}>⚠️ Neutral</div>
                </div>
                <div className={styles.metric}>
                  <div
                    className={styles.metricValue}
                    style={{ color: getRiskColor(result.summary.highest_risk) }}
                  >
                    {getRiskEmoji(result.summary.highest_risk)}{" "}
                    {result.summary.highest_risk.toUpperCase()}
                  </div>
                  <div className={styles.metricLabel}>Risk Level</div>
                </div>
              </div>

              {/* Language Info */}
              {result.language_support === "partial" && (
                <div className={styles.infoBox}>
                  ℹ️ Detected {result.language_name}. Explanation shown in
                  English due to limited local-language support.
                </div>
              )}

              {/* Visual Forensics Warning */}
              {result.visual_forensics?.suspicion_level &&
                ["medium", "high"].includes(
                  result.visual_forensics.suspicion_level
                ) && (
                  <div className={styles.warningBox}>
                    ⚠️ Visual Forensics:{" "}
                    {result.visual_forensics.suspicion_level.toUpperCase()}{" "}
                    suspicion of image manipulation detected
                  </div>
                )}

              {/* Individual Claims */}
              {result.results.map((claim, idx) => (
                <div key={claim.claim_id} className={styles.claimCard}>
                  <h3 className={styles.claimTitle}>Claim #{idx + 1}</h3>

                  <div
                    className={`${styles.verdictBox} ${
                      styles[`verdict-${claim.user_label.toLowerCase()}`]
                    }`}
                  >
                    <div className={styles.verdictContent}>
                      <div className={styles.claimText}>{claim.claim}</div>
                      <div className={styles.verdictInfo}>
                        <div>
                          <strong>Verdict:</strong> {claim.user_label}
                        </div>
                        <div>
                          <strong>Confidence:</strong> {claim.confidence}%
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={styles.explanation}>
                    <h4>Explanation:</h4>
                    {result.primary_language !== "en" &&
                      result.language_support === "full" && (
                        <div className={styles.localExplanation}>
                          🌍 {result.language_name}:{" "}
                          {claim.short_explain_local}
                        </div>
                      )}
                    <div className={styles.englishExplanation}>
                      🇬🇧 English: {claim.short_explain_en}
                    </div>
                  </div>

                  <div className={styles.metricsRow}>
                    <div className={styles.metricBox}>
                      <div className={styles.metricLabel}>Virality Score</div>
                      <div className={styles.metricValue}>
                        {claim.virality_score}/100
                      </div>
                    </div>
                    <div className={styles.metricBox}>
                      <div className={styles.metricLabel}>Risk Level</div>
                      <div
                        className={styles.riskBadge}
                        style={{
                          backgroundColor: getRiskColor(
                            claim.combined_risk_level
                          ),
                        }}
                      >
                        {claim.combined_risk_level.toUpperCase()}
                      </div>
                    </div>
                  </div>

                  {/* Evidence */}
                  {showEvidence && claim.evidence && (
                    <details className={styles.evidenceDetails}>
                      <summary>🔍 Evidence Sources</summary>
                      <div className={styles.evidenceList}>
                        {claim.evidence.slice(0, 5).map((ev, evIdx) => (
                          <div key={evIdx} className={styles.evidenceItem}>
                            <strong>
                              {evIdx + 1}. [{ev.source_type.toUpperCase()}]{" "}
                              {ev.title}
                            </strong>
                            <div>Credibility: {ev.credibility_score}/100</div>
                            <a
                              href={ev.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className={styles.evidenceLink}
                            >
                              {ev.url}
                            </a>
                          </div>
                        ))}
                      </div>
                    </details>
                  )}

                  {/* PDF Download */}
                  {claim.receipt_pdf_path && (
                    <a
                      href={`http://localhost:8000/api/download/${claim.claim_id}`}
                      download
                      className={styles.downloadBtn}
                    >
                      📄 Download Verification Receipt (PDF)
                    </a>
                  )}

                  {claim.needs_human_review && (
                    <div className={styles.warningBox}>
                      ⚠️ This claim requires human review due to sensitivity or
                      low confidence.
                    </div>
                  )}
                </div>
              ))}

              <button className={styles.clearBtn} onClick={clearResults}>
                🔄 Clear Results
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VerificationPage;
