/// <reference types="vite/client" />

GOOGLE_API_KEY = "AIzaSyC0KznLSn7how-Lf2rRe3zXHo0NEpKYomQ"